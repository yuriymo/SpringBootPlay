create unique index CUSTOMER_ID_UINDEX
    on CUSTOMER (ID);

